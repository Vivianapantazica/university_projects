# python script showing battery details
from time import time
import psutil

# function returning time in hh:mm:ss
def convertTime(seconds):
	minutes, seconds = divmod(seconds, 60)
	hours, minutes = divmod(minutes, 60)
	return "%d:%02d:%02d" % (hours, minutes, seconds)

# returns a tuple
battery = psutil.sensors_battery()

percentage = "Battery percentage : ", battery.percent

isPluggedIn = "Power plugged in : ", battery.power_plugged

# converting seconds to hh:mm:ss
timeLeft = "Battery left : ", convertTime(battery.secsleft)

# GRAPHIC DISPLAY
from tkinter import *

root = Tk()

label = Label(
    text="Battery Info Display",
    foreground="white",  
    background="black"
)
label.pack()

def changetext():
	a.config(text=timeLeft)
    
a = Label(
		root, 
		text=isPluggedIn,
)

a.configure(width = 100, 
			foreground = "white", 
			background = "orange", 
			activebackground = "#33B5E5", 
			relief = FLAT)
a.pack()
Button(
	root, 
	text=percentage, 
	foreground="black",  
    background="pink",
	command=changetext).pack()

root.mainloop()